class Topic {
  String topic;
  int count;
  Topic({this.topic,this.count});
}