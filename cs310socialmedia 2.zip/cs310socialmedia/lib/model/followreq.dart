class feed_follow{
  String date; //when it is sent
  String userprofile_img;
  int userID;
  String username; //the user who send like, comment or follow request
  feed_follow({this.date, this.userprofile_img,this.userID,this.username});
}