class Location {
  String location;
  int numOfPosts;

  Location({ this.location, this.numOfPosts});
}